#!/bin/bash

printf "%s: %s\n" "$(hostname --short)" "$(date --iso-8601=ns)"
